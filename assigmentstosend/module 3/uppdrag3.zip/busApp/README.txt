här är länken till mon dokumentation till buus programmet

https://doc.clickup.com/d/h/4amze-659/13276800b8cb889
