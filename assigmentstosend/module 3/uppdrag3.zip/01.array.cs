﻿using System;

namespace console1
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] myNumbers = new int[10];
            System.Console.WriteLine("array: " + myNumbers);

        }

    }
}
