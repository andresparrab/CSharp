# Modern-Media-Player-UI-C-Sharp
<img src="https://i1.wp.com/rjcodeadvance.com/wp-content/uploads/2019/09/portada-MODERN-UI-SLIDING-MENU-WINDOWS-FORM.png?w=1921&ssl=1">
<h1>tutorial C#</h1>
https://www.youtube.com/watch?v=3ni0V-l3Auw
